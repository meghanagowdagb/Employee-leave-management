$(document).ready(function() {
    $(".masked").inputmask();
    // PrettyPrint
    $('pre').addClass('prettyprint');
    prettyPrint();
});